"""QCompiler package for the Lab2 compiler pipeline."""

