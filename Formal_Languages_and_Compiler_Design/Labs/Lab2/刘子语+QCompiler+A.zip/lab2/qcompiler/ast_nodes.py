from __future__ import annotations

from dataclasses import dataclass, fields, is_dataclass
from typing import Any


@dataclass
class VarDecl:
    type_name: str
    name: str
    array_lengths: list[int]


@dataclass
class Param:
    type_name: str
    name: str
    is_array: bool


@dataclass
class Program:
    globals: list[VarDecl]
    functions: list[FunctionDecl]
    statements: list[Stmt]


@dataclass
class FunctionDecl:
    return_type: str
    name: str
    params: list[Param]
    body: Block


class Stmt:
    pass


@dataclass
class Block(Stmt):
    decls: list[VarDecl]
    statements: list[Stmt]


@dataclass
class EmptyStmt(Stmt):
    pass


@dataclass
class ExprStmt(Stmt):
    expr: Expr


@dataclass
class IfStmt(Stmt):
    condition: Expr
    then_branch: Stmt
    else_branch: Stmt | None


@dataclass
class WhileStmt(Stmt):
    condition: Expr
    body: Stmt


@dataclass
class ReturnStmt(Stmt):
    value: Expr | None


class Expr:
    pass


@dataclass
class Number(Expr):
    value: int


@dataclass
class Var(Expr):
    name: str


@dataclass
class ArrayDecay(Expr):
    name: str


@dataclass
class ArrayAccess(Expr):
    array: Expr
    index: Expr


@dataclass
class Call(Expr):
    name: str
    args: list[Expr]


@dataclass
class UnaryOp(Expr):
    op: str
    expr: Expr


@dataclass
class BinaryOp(Expr):
    op: str
    left: Expr
    right: Expr


@dataclass
class Assign(Expr):
    target: Expr
    op: str
    value: Expr


def node_to_data(value: Any) -> Any:
    if is_dataclass(value):
        data = {"node": value.__class__.__name__}
        for field in fields(value):
            data[field.name] = node_to_data(getattr(value, field.name))
        return data
    if isinstance(value, list):
        return [node_to_data(item) for item in value]
    if isinstance(value, dict):
        return {key: node_to_data(item) for key, item in value.items()}
    return value
