from __future__ import annotations

import math
import re
from dataclasses import dataclass

from qcompiler.qtac import GlobalSymbol, TACFunction, TACInstruction, TACOperand, TACProgram


ARG_REGS = [f"X{i}" for i in range(8)]
CALLEE_SAVED = [f"X{i}" for i in range(19, 29)]
SCRATCH = ["X9", "X10", "X11", "X12", "X13", "X14", "X15"]

BRANCH_MAP = {
    "<": "B.LT",
    "<=": "B.LE",
    ">": "B.GT",
    ">=": "B.GE",
    "==": "B.EQ",
    "!=": "B.NE",
}

AOP_INSTR = {
    "+": "ADD",
    "-": "SUB",
    "*": "MUL",
    "/": "SDIV",
}

PEEPHOLE_SCRATCH = {f"X{i}" for i in range(9, 16)}


@dataclass(frozen=True)
class Location:
    kind: str
    value: str | int


def dedupe(items: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        if item not in seen:
            seen.add(item)
            out.append(item)
    return out


def operand_reads(operand: TACOperand) -> list[str]:
    return [operand.value] if operand.kind == "var" else []


def stmt_reads_writes(stmt: TACInstruction) -> tuple[list[str], list[str]]:
    reads: list[str] = []
    writes: list[str] = []
    data = stmt.data

    if stmt.template == "T_MOVE":
        writes.extend(operand_reads(data["dst"]))
        reads.extend(operand_reads(data["src"]))
    elif stmt.template == "T_AOP":
        writes.extend(operand_reads(data["dst"]))
        reads.extend(operand_reads(data["left"]))
        reads.extend(operand_reads(data["right"]))
    elif stmt.template == "T_IF":
        reads.extend(operand_reads(data["left"]))
        reads.extend(operand_reads(data["right"]))
    elif stmt.template == "T_RETURN":
        reads.extend(operand_reads(data["value"]))
    elif stmt.template == "T_PAR":
        reads.extend(operand_reads(data["value"]))
    elif stmt.template == "T_CALL":
        writes.extend(operand_reads(data["dst"]))
    elif stmt.template == "T_LDR0":
        writes.extend(operand_reads(data["dst"]))
        reads.extend(operand_reads(data["base"]))
    elif stmt.template == "T_STR0":
        reads.extend(operand_reads(data["base"]))
        reads.extend(operand_reads(data["src"]))
    elif stmt.template == "T_GOTO":
        reads.extend(operand_reads(data["target"]))

    return dedupe(reads), dedupe(writes)


def collect_symbols(statements: list[TACInstruction], params: list[str]) -> list[str]:
    symbols = list(params)
    seen = set(symbols)
    for stmt in statements:
        reads, writes = stmt_reads_writes(stmt)
        for name in reads + writes:
            if name not in seen:
                seen.add(name)
                symbols.append(name)
    return symbols


def assign_locations(symbols: list[str]) -> dict[str, Location]:
    locations: dict[str, Location] = {}
    stack_index = 0
    for idx, sym in enumerate(symbols):
        if idx < len(CALLEE_SAVED):
            locations[sym] = Location("reg", CALLEE_SAVED[idx])
        else:
            locations[sym] = Location("stack", stack_index * 8)
            stack_index += 1
    return locations


class CodegenContext:
    def __init__(
        self,
        name: str,
        params: list[str],
        statements: list[TACInstruction],
        entry: bool = False,
    ):
        self.name = name
        self.params = params
        self.statements = statements
        self.entry = entry
        if len(self.params) > len(ARG_REGS):
            raise ValueError("AArch64 call support is limited to 8 parameters")
        self.symbols = collect_symbols(statements, params)
        self.locations = assign_locations(self.symbols)
        self.used_callee = dedupe(
            [str(loc.value) for loc in self.locations.values() if loc.kind == "reg"]
        )
        self.stack_slots = sum(1 for loc in self.locations.values() if loc.kind == "stack")
        self.save_area = 0 if entry else len(self.used_callee) * 8
        self.local_area = self.stack_slots * 8
        raw_frame = self.save_area + self.local_area
        self.frame_size = int(math.ceil(raw_frame / 16.0) * 16) if raw_frame else 0
        self.return_label = f".L_return_{name}"
        self.pending_args: list[TACOperand] = []
        self.out: list[str] = []

    def asm_label(self, label: str) -> str:
        if label == self.name:
            return label
        return f".L_{self.name}_{label}"

    def emit(self, line: str) -> None:
        self.out.append(line)

    def save_offset(self, idx: int) -> int:
        return idx * 8

    def symbol_offset(self, name: str) -> int:
        loc = self.locations[name]
        if loc.kind != "stack":
            raise ValueError(f"{name} is not stack allocated")
        return self.save_area + int(loc.value)

    def load_symbol(self, name: str, reg: str) -> str:
        loc = self.locations[name]
        if loc.kind == "reg":
            phys = str(loc.value)
            if phys != reg:
                self.emit(f"    MOV {reg}, {phys}")
            return reg
        self.emit(f"    LDR {reg}, [SP, #{self.symbol_offset(name)}]")
        return reg

    def store_symbol(self, name: str, reg: str) -> None:
        loc = self.locations[name]
        if loc.kind == "reg":
            phys = str(loc.value)
            if phys != reg:
                self.emit(f"    MOV {phys}, {reg}")
            return
        self.emit(f"    STR {reg}, [SP, #{self.symbol_offset(name)}]")

    def load_operand(self, operand: TACOperand, reg: str) -> str:
        if operand.kind == "imm":
            self.emit(f"    MOV {reg}, #{operand.value}")
            return reg
        if operand.kind == "var":
            return self.load_symbol(operand.value, reg)
        if operand.kind == "global":
            self.emit(f"    ADR {reg}, {operand.value}")
            return reg
        raise ValueError(f"Cannot load operand {operand.kind}")

    def emit_prologue(self) -> None:
        self.emit(f".global {self.name}")
        self.emit(f"{self.name}:")
        if self.entry:
            if self.frame_size:
                self.emit(f"    SUB SP, SP, #{self.frame_size}")
            return
        self.emit("    STP X29, X30, [SP, #-16]!")
        self.emit("    MOV X29, SP")
        if self.frame_size:
            self.emit(f"    SUB SP, SP, #{self.frame_size}")
        for idx, reg in enumerate(self.used_callee):
            self.emit(f"    STR {reg}, [SP, #{self.save_offset(idx)}]")
        for idx, param in enumerate(self.params):
            self.store_symbol(param, ARG_REGS[idx])

    def emit_epilogue(self) -> None:
        if self.entry:
            if self.frame_size:
                self.emit(f"    ADD SP, SP, #{self.frame_size}")
            self.emit("    MOV X0, #0")
            self.emit("    MOV X8, #93")
            self.emit("    SVC #0")
            return
        self.emit(f"{self.return_label}:")
        for idx, reg in enumerate(self.used_callee):
            self.emit(f"    LDR {reg}, [SP, #{self.save_offset(idx)}]")
        if self.frame_size:
            self.emit(f"    ADD SP, SP, #{self.frame_size}")
        self.emit("    LDP X29, X30, [SP], #16")
        self.emit("    RET")

    def emit_stmt(self, stmt: TACInstruction) -> None:
        data = stmt.data
        tpl = stmt.template

        if tpl == "T_LABEL":
            if data["label"] == self.name:
                return
            self.emit(f"{self.asm_label(data['label'])}:")
            return

        if tpl == "T_GOTO":
            target = data["target"]
            if target.kind == "label":
                self.emit(f"    B {self.asm_label(target.value)}")
            else:
                reg = self.load_operand(target, SCRATCH[0])
                self.emit(f"    BR {reg}")
            return

        if tpl == "T_RETURN":
            value = data["value"]
            self.load_operand(value, "X0")
            self.emit(f"    B {self.return_label}")
            return

        if tpl == "T_PAR":
            self.pending_args.append(data["value"])
            return

        if tpl == "T_CALL":
            argc = data["argc"]
            if argc != len(self.pending_args):
                raise ValueError(f"CALL expects {argc} PAR instructions, saw {len(self.pending_args)}")
            for idx, operand in enumerate(self.pending_args):
                self.load_operand(operand, ARG_REGS[idx])
            self.emit(f"    BL {data['func']}")
            self.store_symbol(data["dst"].value, "X0")
            self.pending_args.clear()
            return

        if tpl == "T_MOVE":
            self.load_operand(data["src"], SCRATCH[0])
            self.store_symbol(data["dst"].value, SCRATCH[0])
            return

        if tpl == "T_AOP":
            left = self.load_operand(data["left"], SCRATCH[0])
            result = SCRATCH[2]
            op = data["op"]
            right = data["right"]
            if op in {"+", "-"} and right.kind == "imm":
                self.emit(f"    {AOP_INSTR[op]} {result}, {left}, #{right.value}")
            else:
                right_reg = self.load_operand(right, SCRATCH[1])
                self.emit(f"    {AOP_INSTR[op]} {result}, {left}, {right_reg}")
            self.store_symbol(data["dst"].value, result)
            return

        if tpl == "T_IF":
            left = self.load_operand(data["left"], SCRATCH[0])
            self.load_operand(data["right"], SCRATCH[1])
            self.emit(f"    CMP {left}, {SCRATCH[1]}")
            self.emit(f"    {BRANCH_MAP[data['op']]} {self.asm_label(data['true_label'])}")
            self.emit(f"    B {self.asm_label(data['false_label'])}")
            return

        if tpl == "T_LDR0":
            self.load_operand(data["base"], SCRATCH[0])
            self.emit(f"    LDR {SCRATCH[1]}, [{SCRATCH[0]}]")
            self.store_symbol(data["dst"].value, SCRATCH[1])
            return

        if tpl == "T_STR0":
            self.load_operand(data["base"], SCRATCH[0])
            self.load_operand(data["src"], SCRATCH[1])
            self.emit(f"    STR {SCRATCH[1]}, [{SCRATCH[0]}]")
            return

        if tpl == "T_NOP":
            self.emit("    NOP")
            return

        raise ValueError(f"Unsupported TAC template {tpl}")

    def generate(self) -> str:
        self.emit_prologue()
        for stmt in self.statements:
            self.emit_stmt(stmt)
        self.emit_epilogue()
        return "\n".join(self.out)


def generate_arm(program: TACProgram) -> str:
    lines: list[str] = []
    if program.globals:
        lines.append(".section .data")
        lines.append(".align 3")
        for symbol in program.globals:
            lines.append(f"{symbol.name}: .skip {symbol.size}")
        lines.append("")

    lines.append(".section .text")
    for function in program.functions:
        lines.append(generate_function_arm(function))
        lines.append("")
    entry_context = CodegenContext("_start", [], program.main, entry=True)
    lines.append(entry_context.generate())
    return "\n".join(lines).rstrip() + "\n"


def generate_function_arm(function: TACFunction) -> str:
    return CodegenContext(function.name, function.params, function.instructions).generate()


def optimize_asm(asm: str) -> str:
    lines = asm.splitlines()
    previous: list[str] | None = None
    while previous != lines:
        previous = lines
        lines = peephole_pass(lines)
    return "\n".join(lines).rstrip() + "\n"


def peephole_pass(lines: list[str]) -> list[str]:
    out: list[str] = []
    idx = 0
    mov_same = re.compile(r"\s*MOV\s+(X[0-9]+),\s*\1\s*$")
    mov_reg = re.compile(r"(\s*)MOV\s+(X[0-9]+),\s+(X[0-9]+)\s*$")
    mov_imm8 = re.compile(r"(\s*)MOV\s+(X[0-9]+),\s+#8\s*$")
    three_reg = re.compile(r"(\s*)(ADD|SUB|MUL|SDIV)\s+(X[0-9]+),\s+(X[0-9]+),\s+(X[0-9]+)\s*$")
    imm_arith = re.compile(r"(\s*)(ADD|SUB)\s+(X[0-9]+),\s+(X[0-9]+),\s+#([0-9]+)\s*$")
    lsl = re.compile(r"(\s*)LSL\s+(X[0-9]+),\s+(X[0-9]+),\s+#3\s*$")
    ldr = re.compile(r"(\s*)LDR\s+(X[0-9]+),\s+(\[[^\]]+\])\s*$")
    str_reg = re.compile(r"(\s*)STR\s+(X[0-9]+),\s+(\[[^\]]+\])\s*$")
    cmp_reg = re.compile(r"(\s*)CMP\s+(X[0-9]+),\s+(X[0-9]+)\s*$")

    while idx < len(lines):
        line = lines[idx]
        stripped = line.strip()

        if mov_same.match(line):
            idx += 1
            continue

        if idx + 1 < len(lines):
            next_line = lines[idx + 1]

            mov8 = mov_imm8.match(line)
            mul = three_reg.match(next_line)
            if mov8 and mul and mul.group(2) == "MUL" and mov8.group(2) == mul.group(5):
                out.append(f"{mul.group(1)}LSL {mul.group(3)}, {mul.group(4)}, #3")
                idx += 2
                continue

            mov = mov_reg.match(line)
            if mov and mov.group(2) in PEEPHOLE_SCRATCH:
                indent, tmp, src = mov.groups()
                op = three_reg.match(next_line)
                if op and op.group(4) == tmp and op.group(3) != tmp and op.group(5) != tmp:
                    out.append(f"{op.group(1)}{op.group(2)} {op.group(3)}, {src}, {op.group(5)}")
                    idx += 2
                    continue
                op_imm = imm_arith.match(next_line)
                if op_imm and op_imm.group(4) == tmp and op_imm.group(3) != tmp:
                    out.append(
                        f"{op_imm.group(1)}{op_imm.group(2)} "
                        f"{op_imm.group(3)}, {src}, #{op_imm.group(5)}"
                    )
                    idx += 2
                    continue
                shift = lsl.match(next_line)
                if shift and shift.group(3) == tmp and shift.group(2) != tmp:
                    out.append(f"{shift.group(1)}LSL {shift.group(2)}, {src}, #3")
                    idx += 2
                    continue
                compare = cmp_reg.match(next_line)
                if compare and compare.group(2) == tmp:
                    out.append(f"{compare.group(1)}CMP {src}, {compare.group(3)}")
                    idx += 2
                    continue
                store = str_reg.match(next_line)
                if store and store.group(2) == tmp and tmp not in store.group(3):
                    out.append(f"{store.group(1)}STR {src}, {store.group(3)}")
                    idx += 2
                    continue
                mov2 = mov_reg.match(next_line)
                if mov2 and mov2.group(2) != tmp and mov2.group(3) == tmp:
                    out.append(f"{indent}MOV {mov2.group(2)}, {src}")
                    idx += 2
                    continue

            load = ldr.match(line)
            mov_after_load = mov_reg.match(next_line)
            if (
                load
                and mov_after_load
                and mov_after_load.group(3) == load.group(2)
                and mov_after_load.group(2) not in load.group(3)
            ):
                out.append(f"{load.group(1)}LDR {mov_after_load.group(2)}, {load.group(3)}")
                idx += 2
                continue

            op = three_reg.match(line) or imm_arith.match(line) or lsl.match(line)
            mov_after_op = mov_reg.match(next_line)
            if op and mov_after_op and mov_after_op.group(3) == op.group(3):
                dst = mov_after_op.group(2)
                if three_reg.match(line):
                    out.append(f"{op.group(1)}{op.group(2)} {dst}, {op.group(4)}, {op.group(5)}")
                elif imm_arith.match(line):
                    out.append(f"{op.group(1)}{op.group(2)} {dst}, {op.group(4)}, #{op.group(5)}")
                else:
                    out.append(f"{op.group(1)}LSL {dst}, {op.group(3)}, #3")
                idx += 2
                continue

        if stripped.startswith("B ") and not stripped.startswith("B."):
            target = stripped.split()[1]
            next_label = next((item.strip() for item in lines[idx + 1 :] if item.strip()), "")
            if next_label == f"{target}:":
                idx += 1
                continue

        out.append(line)
        idx += 1

    return out
