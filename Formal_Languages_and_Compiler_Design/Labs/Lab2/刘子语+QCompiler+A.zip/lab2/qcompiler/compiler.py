from __future__ import annotations

import json
from dataclasses import dataclass

from qcompiler.arm import generate_arm, optimize_asm
from qcompiler.ast_nodes import node_to_data
from qcompiler.lexer import Lexer, Token, format_tokens
from qcompiler.parser import Parser
from qcompiler.qtac import TACGenerator


@dataclass
class CompileResult:
    tokens: list[Token]
    tokens_text: str
    ast_json: str
    qtac: str
    symbol_table: str
    arm: str
    optimized_arm: str


def compile_source(source: str) -> CompileResult:
    tokens = Lexer().tokenize(source)
    ast = Parser(tokens).parse()
    ast_json = json.dumps(node_to_data(ast), ensure_ascii=False, indent=2)
    tac_program = TACGenerator().generate(ast)
    arm = generate_arm(tac_program)
    optimized_arm = optimize_asm(arm)
    return CompileResult(
        tokens=tokens,
        tokens_text=format_tokens(tokens),
        ast_json=ast_json + "\n",
        qtac=tac_program.to_text(),
        symbol_table=tac_program.symbol_table_text(),
        arm=arm,
        optimized_arm=optimized_arm,
    )

