from __future__ import annotations

import argparse
from pathlib import Path

from qcompiler.compiler import compile_source


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Compile QL source to QAST, QTAC, and ARM64 assembly.")
    parser.add_argument("source", type=Path, help="QL source file")
    parser.add_argument("-o", "--out-dir", type=Path, default=None, help="Output directory")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    source_path: Path = args.source
    out_dir = args.out_dir or source_path.with_suffix("")
    out_dir.mkdir(parents=True, exist_ok=True)

    result = compile_source(source_path.read_text(encoding="utf-8"))
    stem = source_path.stem
    outputs = {
        f"{stem}.tokens.txt": result.tokens_text,
        f"{stem}.ast.json": result.ast_json,
        f"{stem}.qtac": result.qtac,
        f"{stem}.symbols.txt": result.symbol_table,
        f"{stem}.s": result.arm,
        f"{stem}_opt.s": result.optimized_arm,
    }
    for name, content in outputs.items():
        (out_dir / name).write_text(content, encoding="utf-8")
    print(f"generated {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

