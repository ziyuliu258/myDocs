from __future__ import annotations

from dataclasses import dataclass

from qcompiler.ast_nodes import (
    ArrayAccess,
    ArrayDecay,
    Assign,
    BinaryOp,
    Block,
    Call,
    EmptyStmt,
    Expr,
    ExprStmt,
    FunctionDecl,
    IfStmt,
    Number,
    Program,
    ReturnStmt,
    Stmt,
    UnaryOp,
    Var,
    VarDecl,
    WhileStmt,
)


ARITH_OPS = {"+", "-", "*", "/"}
REL_OPS = {"<", "<=", ">", ">=", "==", "!="}
WORD_SIZE = 8


@dataclass(frozen=True)
class TACOperand:
    kind: str
    value: str

    def text(self) -> str:
        return self.value


@dataclass(frozen=True)
class GlobalSymbol:
    name: str
    size: int


@dataclass(frozen=True)
class TACInstruction:
    template: str
    data: dict

    def to_text(self) -> str:
        d = self.data
        if self.template == "T_LABEL":
            return f"LABEL {d['label']};"
        if self.template == "T_GOTO":
            return f"GOTO {d['target'].text()};"
        if self.template == "T_RETURN":
            return f"RETURN {d['value'].text()};"
        if self.template == "T_PAR":
            return f"PAR {d['value'].text()};"
        if self.template == "T_IF":
            return (
                f"IF {d['left'].text()} {d['op']} {d['right'].text()} "
                f"THEN {d['true_label']} ELSE {d['false_label']};"
            )
        if self.template == "T_MOVE":
            return f"{d['dst'].text()} = {d['src'].text()};"
        if self.template == "T_AOP":
            return f"{d['dst'].text()} = {d['left'].text()} {d['op']} {d['right'].text()};"
        if self.template == "T_CALL":
            return f"{d['dst'].text()} = CALL {d['func']}, {d['argc']};"
        if self.template == "T_LDR0":
            return f"{d['dst'].text()} = M[{d['base'].text()}];"
        if self.template == "T_STR0":
            return f"M[{d['base'].text()}] = {d['src'].text()};"
        if self.template == "T_NOP":
            return "NOP;"
        raise ValueError(f"Unknown TAC template {self.template}")


@dataclass
class TACFunction:
    name: str
    params: list[str]
    locals: list[str]
    instructions: list[TACInstruction]

    def to_text(self) -> str:
        params = ", ".join(self.params)
        body = "\n".join(ins.to_text() for ins in self.instructions)
        return f"define {self.name}({params}){{\n{body}\n}}"


@dataclass
class TACProgram:
    globals: list[GlobalSymbol]
    functions: list[TACFunction]
    main: list[TACInstruction]

    def to_text(self) -> str:
        lines: list[str] = []
        for symbol in self.globals:
            lines.append(f"i{symbol.size} {symbol.name};")
        if self.globals:
            lines.append("")
        for function in self.functions:
            lines.append(function.to_text())
            lines.append("")
        lines.extend(ins.to_text() for ins in self.main)
        return "\n".join(lines).rstrip() + "\n"

    def symbol_table_text(self) -> str:
        lines = ["globals:"]
        for symbol in self.globals:
            lines.append(f"  {symbol.name}: {symbol.size} bytes")
        lines.append("functions:")
        for function in self.functions:
            lines.append(f"  {function.name}:")
            lines.append(f"    params: {', '.join(function.params) if function.params else '(none)'}")
            lines.append(f"    locals: {', '.join(function.locals) if function.locals else '(none)'}")
        return "\n".join(lines) + "\n"


class GenContext:
    def __init__(self, global_names: set[str], local_names: set[str]):
        self.global_names = global_names
        self.local_names = local_names
        self.instructions: list[TACInstruction] = []
        self.temp_index = 0
        self.label_index = 0

    def temp(self) -> TACOperand:
        value = f"t{self.temp_index}"
        self.temp_index += 1
        return TACOperand("var", value)

    def label(self) -> str:
        value = f"l{self.label_index}"
        self.label_index += 1
        return value

    def operand_for_name(self, name: str) -> TACOperand:
        if name in self.global_names and name not in self.local_names:
            return TACOperand("global", name)
        return TACOperand("var", name)

    def emit(self, template: str, data: dict) -> None:
        self.instructions.append(TACInstruction(template, data))

    def emit_label(self, label: str) -> None:
        self.emit("T_LABEL", {"label": label})

    def emit_goto(self, label: str) -> None:
        self.emit("T_GOTO", {"target": TACOperand("label", label)})


class TACGenerator:
    def generate(self, program: Program) -> TACProgram:
        globals_ = [self.global_symbol(decl) for decl in program.globals]
        global_names = {symbol.name for symbol in globals_}
        functions = [self.generate_function(function, global_names) for function in program.functions]
        main_context = GenContext(global_names, set())
        for stmt in program.statements:
            self.emit_stmt(stmt, main_context)
        return TACProgram(globals_, functions, main_context.instructions)

    def global_symbol(self, decl: VarDecl) -> GlobalSymbol:
        count = 1
        for length in decl.array_lengths:
            count *= length
        return GlobalSymbol(decl.name, count * WORD_SIZE)

    def generate_function(self, function: FunctionDecl, global_names: set[str]) -> TACFunction:
        params = [param.name for param in function.params]
        locals_ = self.collect_local_names(function.body)
        local_names = set(params) | set(locals_)
        context = GenContext(global_names, local_names)
        context.emit_label(function.name)
        for stmt in function.body.statements:
            self.emit_stmt(stmt, context)
        if not context.instructions or context.instructions[-1].template != "T_RETURN":
            context.emit("T_RETURN", {"value": TACOperand("imm", "0")})
        return TACFunction(function.name, params, locals_, context.instructions)

    def collect_local_names(self, block: Block) -> list[str]:
        names: list[str] = []

        def walk_block(item: Block) -> None:
            for decl in item.decls:
                names.append(decl.name)
            for stmt in item.statements:
                if isinstance(stmt, Block):
                    walk_block(stmt)
                elif isinstance(stmt, IfStmt):
                    walk_stmt(stmt.then_branch)
                    if stmt.else_branch is not None:
                        walk_stmt(stmt.else_branch)
                elif isinstance(stmt, WhileStmt):
                    walk_stmt(stmt.body)

        def walk_stmt(stmt: Stmt) -> None:
            if isinstance(stmt, Block):
                walk_block(stmt)
            elif isinstance(stmt, IfStmt):
                walk_stmt(stmt.then_branch)
                if stmt.else_branch is not None:
                    walk_stmt(stmt.else_branch)
            elif isinstance(stmt, WhileStmt):
                walk_stmt(stmt.body)

        walk_block(block)
        return names

    def emit_stmt(self, stmt: Stmt, context: GenContext) -> None:
        if isinstance(stmt, EmptyStmt):
            return
        if isinstance(stmt, Block):
            for inner in stmt.statements:
                self.emit_stmt(inner, context)
            return
        if isinstance(stmt, ExprStmt):
            self.emit_expr(stmt.expr, context)
            return
        if isinstance(stmt, ReturnStmt):
            value = TACOperand("imm", "0") if stmt.value is None else self.emit_expr(stmt.value, context)
            context.emit("T_RETURN", {"value": value})
            return
        if isinstance(stmt, IfStmt):
            true_label = context.label()
            false_label = context.label()
            end_label = context.label()
            self.emit_condition(stmt.condition, true_label, false_label, context)
            context.emit_label(true_label)
            self.emit_stmt(stmt.then_branch, context)
            context.emit_goto(end_label)
            context.emit_label(false_label)
            if stmt.else_branch is not None:
                self.emit_stmt(stmt.else_branch, context)
            context.emit_label(end_label)
            return
        if isinstance(stmt, WhileStmt):
            start_label = context.label()
            body_label = context.label()
            end_label = context.label()
            context.emit_label(start_label)
            self.emit_condition(stmt.condition, body_label, end_label, context)
            context.emit_label(body_label)
            self.emit_stmt(stmt.body, context)
            context.emit_goto(start_label)
            context.emit_label(end_label)
            return
        raise TypeError(f"Unsupported statement {stmt!r}")

    def emit_expr(self, expr: Expr, context: GenContext) -> TACOperand:
        if isinstance(expr, Number):
            return TACOperand("imm", str(expr.value))
        if isinstance(expr, Var):
            return context.operand_for_name(expr.name)
        if isinstance(expr, ArrayDecay):
            return context.operand_for_name(expr.name)
        if isinstance(expr, ArrayAccess):
            address = self.emit_address(expr, context)
            dst = context.temp()
            context.emit("T_LDR0", {"dst": dst, "base": address})
            return dst
        if isinstance(expr, Call):
            for arg in expr.args:
                context.emit("T_PAR", {"value": self.emit_expr(arg, context)})
            dst = context.temp()
            context.emit("T_CALL", {"dst": dst, "func": expr.name, "argc": len(expr.args)})
            return dst
        if isinstance(expr, Assign):
            return self.emit_assign(expr, context)
        if isinstance(expr, UnaryOp):
            if expr.op == "-":
                value = self.emit_expr(expr.expr, context)
                dst = context.temp()
                context.emit(
                    "T_AOP",
                    {"dst": dst, "left": TACOperand("imm", "0"), "op": "-", "right": value},
                )
                return dst
            if expr.op == "!":
                return self.emit_bool_expr(expr, context)
        if isinstance(expr, BinaryOp):
            if expr.op in ARITH_OPS:
                left = self.emit_expr(expr.left, context)
                right = self.emit_expr(expr.right, context)
                dst = context.temp()
                context.emit("T_AOP", {"dst": dst, "left": left, "op": expr.op, "right": right})
                return dst
            if expr.op in REL_OPS or expr.op in {"&&", "||"}:
                return self.emit_bool_expr(expr, context)
        raise TypeError(f"Unsupported expression {expr!r}")

    def emit_bool_expr(self, expr: Expr, context: GenContext) -> TACOperand:
        result = context.temp()
        true_label = context.label()
        false_label = context.label()
        end_label = context.label()
        self.emit_condition(expr, true_label, false_label, context)
        context.emit_label(true_label)
        context.emit("T_MOVE", {"dst": result, "src": TACOperand("imm", "1")})
        context.emit_goto(end_label)
        context.emit_label(false_label)
        context.emit("T_MOVE", {"dst": result, "src": TACOperand("imm", "0")})
        context.emit_label(end_label)
        return result

    def emit_assign(self, expr: Assign, context: GenContext) -> TACOperand:
        rhs = self.emit_expr(expr.value, context)
        if isinstance(expr.target, Var):
            target = context.operand_for_name(expr.target.name)
            if expr.op == "+=":
                tmp = context.temp()
                context.emit("T_AOP", {"dst": tmp, "left": target, "op": "+", "right": rhs})
                rhs = tmp
            if target.kind == "global":
                context.emit("T_STR0", {"base": target, "src": rhs})
            else:
                context.emit("T_MOVE", {"dst": target, "src": rhs})
            return target

        if isinstance(expr.target, ArrayAccess):
            address = self.emit_address(expr.target, context)
            value = rhs
            if expr.op == "+=":
                current = context.temp()
                context.emit("T_LDR0", {"dst": current, "base": address})
                value = context.temp()
                context.emit("T_AOP", {"dst": value, "left": current, "op": "+", "right": rhs})
            context.emit("T_STR0", {"base": address, "src": value})
            return value

        raise TypeError(f"Unsupported assignment target {expr.target!r}")

    def emit_address(self, expr: ArrayAccess, context: GenContext) -> TACOperand:
        base = self.emit_array_base(expr.array, context)
        index = self.emit_expr(expr.index, context)
        scaled = self.scale_index(index, context)
        address = context.temp()
        context.emit("T_AOP", {"dst": address, "left": base, "op": "+", "right": scaled})
        return address

    def emit_array_base(self, expr: Expr, context: GenContext) -> TACOperand:
        if isinstance(expr, Var):
            return context.operand_for_name(expr.name)
        if isinstance(expr, ArrayDecay):
            return context.operand_for_name(expr.name)
        if isinstance(expr, ArrayAccess):
            return self.emit_expr(expr, context)
        raise TypeError(f"Unsupported array base {expr!r}")

    def scale_index(self, index: TACOperand, context: GenContext) -> TACOperand:
        if index.kind == "imm":
            return TACOperand("imm", str(int(index.value) * WORD_SIZE))
        scaled = context.temp()
        context.emit(
            "T_AOP",
            {"dst": scaled, "left": index, "op": "*", "right": TACOperand("imm", str(WORD_SIZE))},
        )
        return scaled

    def emit_condition(self, expr: Expr, true_label: str, false_label: str, context: GenContext) -> None:
        if isinstance(expr, UnaryOp) and expr.op == "!":
            self.emit_condition(expr.expr, false_label, true_label, context)
            return
        if isinstance(expr, BinaryOp) and expr.op == "&&":
            mid_label = context.label()
            self.emit_condition(expr.left, mid_label, false_label, context)
            context.emit_label(mid_label)
            self.emit_condition(expr.right, true_label, false_label, context)
            return
        if isinstance(expr, BinaryOp) and expr.op == "||":
            mid_label = context.label()
            self.emit_condition(expr.left, true_label, mid_label, context)
            context.emit_label(mid_label)
            self.emit_condition(expr.right, true_label, false_label, context)
            return
        if isinstance(expr, BinaryOp) and expr.op in REL_OPS:
            left = self.emit_expr(expr.left, context)
            right = self.emit_expr(expr.right, context)
            context.emit(
                "T_IF",
                {
                    "left": left,
                    "op": expr.op,
                    "right": right,
                    "true_label": true_label,
                    "false_label": false_label,
                },
            )
            return

        value = self.emit_expr(expr, context)
        context.emit(
            "T_IF",
            {
                "left": value,
                "op": "!=",
                "right": TACOperand("imm", "0"),
                "true_label": true_label,
                "false_label": false_label,
            },
        )

