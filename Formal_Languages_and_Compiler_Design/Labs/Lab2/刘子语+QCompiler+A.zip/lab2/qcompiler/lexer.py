from __future__ import annotations

from dataclasses import dataclass


KEYWORDS = {"int", "void", "if", "else", "while", "return"}
MULTI_CHAR_TOKENS = ("&&", "||", "<=", ">=", "==", "!=", "+=")
SINGLE_CHAR_TOKENS = set("{}()[];,=+-*/<>!")
NORMALIZED_CHARS = {
    "\u2013": "-",
    "\u2212": "-",
    "\u00d7": "*",
}


@dataclass(frozen=True)
class Token:
    kind: str
    text: str
    line: int
    column: int

    def display(self) -> str:
        return f"({self.kind}, {self.text})"


class Lexer:
    def tokenize(self, source: str) -> list[Token]:
        text = "".join(NORMALIZED_CHARS.get(ch, ch) for ch in source)
        tokens: list[Token] = []
        pos = 0
        line = 1
        col = 1

        while pos < len(text):
            ch = text[pos]

            if ch in " \t\r":
                pos += 1
                col += 1
                continue

            if ch == "\n":
                pos += 1
                line += 1
                col = 1
                continue

            if text.startswith("//", pos):
                while pos < len(text) and text[pos] != "\n":
                    pos += 1
                    col += 1
                continue

            if ch.isdigit():
                start = pos
                start_col = col
                while pos < len(text) and text[pos].isdigit():
                    pos += 1
                    col += 1
                tokens.append(Token("NUMBER", text[start:pos], line, start_col))
                continue

            if ch.isalpha() or ch == "_":
                start = pos
                start_col = col
                while pos < len(text) and (text[pos].isalnum() or text[pos] == "_"):
                    pos += 1
                    col += 1
                word = text[start:pos]
                kind = "KEYWORD" if word in KEYWORDS else "IDENT"
                tokens.append(Token(kind, word, line, start_col))
                continue

            matched = False
            for candidate in MULTI_CHAR_TOKENS:
                if text.startswith(candidate, pos):
                    tokens.append(Token("SYMBOL", candidate, line, col))
                    pos += len(candidate)
                    col += len(candidate)
                    matched = True
                    break
            if matched:
                continue

            if ch in SINGLE_CHAR_TOKENS:
                tokens.append(Token("SYMBOL", ch, line, col))
                pos += 1
                col += 1
                continue

            raise SyntaxError(f"Unexpected character {ch!r} at {line}:{col}")

        return tokens


def format_tokens(tokens: list[Token]) -> str:
    return "\n".join(f"{tok.kind}\t{tok.text}\t{tok.line}:{tok.column}" for tok in tokens) + "\n"

