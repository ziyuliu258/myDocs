from __future__ import annotations

from qcompiler.ast_nodes import (
    ArrayAccess,
    ArrayDecay,
    Assign,
    BinaryOp,
    Block,
    Call,
    EmptyStmt,
    Expr,
    ExprStmt,
    FunctionDecl,
    IfStmt,
    Number,
    Param,
    Program,
    ReturnStmt,
    Stmt,
    UnaryOp,
    Var,
    VarDecl,
    WhileStmt,
)
from qcompiler.lexer import Token


TYPE_KEYWORDS = {"int", "void"}
REL_OPS = {"<", "<=", ">", ">=", "==", "!="}


class Parser:
    def __init__(self, tokens: list[Token]):
        eof_line = tokens[-1].line if tokens else 1
        eof_col = tokens[-1].column + len(tokens[-1].text) if tokens else 1
        self.tokens = tokens + [Token("EOF", "EOF", eof_line, eof_col)]
        self.pos = 0

    def parse(self) -> Program:
        self.expect("{")
        globals_: list[VarDecl] = []
        functions: list[FunctionDecl] = []
        statements: list[Stmt] = []

        while self.is_type():
            type_name = self.parse_type()
            name = self.expect_ident()
            if self.match("("):
                functions.append(self.parse_function_after_header(type_name, name))
            else:
                globals_.append(self.parse_var_decl_tail(type_name, name, require_size=True))
                self.expect(";")

        while not self.check("}"):
            statements.append(self.parse_statement())

        self.expect("}")
        self.expect_kind("EOF")
        return Program(globals_, functions, statements)

    def parse_function_after_header(self, return_type: str, name: str) -> FunctionDecl:
        params: list[Param] = []
        while not self.check(")"):
            param_type = self.parse_type()
            param_name = self.expect_ident()
            is_array = False
            if self.match("["):
                self.expect("]")
                is_array = True
            params.append(Param(param_type, param_name, is_array))
            self.expect(";")
        self.expect(")")
        body = self.parse_block()
        return FunctionDecl(return_type, name, params, body)

    def parse_block(self) -> Block:
        self.expect("{")
        decls: list[VarDecl] = []
        statements: list[Stmt] = []
        while self.is_type():
            type_name = self.parse_type()
            name = self.expect_ident()
            decls.append(self.parse_var_decl_tail(type_name, name, require_size=True))
            self.expect(";")
        while not self.check("}"):
            statements.append(self.parse_statement())
        self.expect("}")
        return Block(decls, statements)

    def parse_var_decl_tail(self, type_name: str, name: str, require_size: bool) -> VarDecl:
        lengths: list[int] = []
        while self.match("["):
            if self.check("]"):
                if require_size:
                    token = self.peek()
                    raise SyntaxError(f"Array size expected at {token.line}:{token.column}")
                lengths.append(0)
            else:
                number = self.expect_kind("NUMBER")
                lengths.append(int(number.text))
            self.expect("]")
        return VarDecl(type_name, name, lengths)

    def parse_statement(self) -> Stmt:
        if self.match(";"):
            return EmptyStmt()
        if self.check("{"):
            return self.parse_block()
        if self.match_keyword("if"):
            self.expect("(")
            condition = self.parse_condition()
            self.expect(")")
            then_branch = self.parse_statement()
            else_branch = self.parse_statement() if self.match_keyword("else") else None
            return IfStmt(condition, then_branch, else_branch)
        if self.match_keyword("while"):
            self.expect("(")
            condition = self.parse_condition()
            self.expect(")")
            return WhileStmt(condition, self.parse_statement())
        if self.match_keyword("return"):
            value = None if self.check(";") else self.parse_condition()
            self.expect(";")
            return ReturnStmt(value)
        expr = self.parse_condition()
        self.expect(";")
        return ExprStmt(expr)

    def parse_condition(self) -> Expr:
        return self.parse_or()

    def parse_or(self) -> Expr:
        expr = self.parse_and()
        while self.match("||"):
            expr = BinaryOp("||", expr, self.parse_and())
        return expr

    def parse_and(self) -> Expr:
        expr = self.parse_not()
        while self.match("&&"):
            expr = BinaryOp("&&", expr, self.parse_not())
        return expr

    def parse_not(self) -> Expr:
        if self.match("!"):
            return UnaryOp("!", self.parse_not())
        return self.parse_relation()

    def parse_relation(self) -> Expr:
        expr = self.parse_expression()
        if self.peek().text in REL_OPS:
            op = self.advance().text
            expr = BinaryOp(op, expr, self.parse_expression())
        return expr

    def parse_expression(self) -> Expr:
        return self.parse_assignment()

    def parse_assignment(self) -> Expr:
        expr = self.parse_additive()
        if self.peek().text in {"=", "+="}:
            op = self.advance().text
            if not isinstance(expr, (Var, ArrayAccess)):
                token = self.peek()
                raise SyntaxError(f"Assignment target expected before {token.line}:{token.column}")
            return Assign(expr, op, self.parse_assignment())
        return expr

    def parse_additive(self) -> Expr:
        expr = self.parse_multiplicative()
        while self.peek().text in {"+", "-"}:
            op = self.advance().text
            expr = BinaryOp(op, expr, self.parse_multiplicative())
        return expr

    def parse_multiplicative(self) -> Expr:
        expr = self.parse_unary()
        while self.peek().text in {"*", "/"}:
            op = self.advance().text
            expr = BinaryOp(op, expr, self.parse_unary())
        return expr

    def parse_unary(self) -> Expr:
        if self.match("-"):
            return UnaryOp("-", self.parse_unary())
        return self.parse_primary()

    def parse_primary(self) -> Expr:
        if self.match("("):
            expr = self.parse_condition()
            self.expect(")")
            return expr

        if self.peek().kind == "NUMBER":
            return Number(int(self.advance().text))

        name = self.expect_ident()
        if self.match("("):
            args: list[Expr] = []
            while not self.check(")"):
                args.append(self.parse_condition())
                if not self.match(","):
                    break
                if self.check(")"):
                    break
            self.expect(")")
            return Call(name, args)

        expr: Expr = Var(name)
        while self.match("["):
            if self.match("]"):
                if not isinstance(expr, Var):
                    token = self.peek()
                    raise SyntaxError(f"Array decay must use an identifier at {token.line}:{token.column}")
                expr = ArrayDecay(expr.name)
                break
            index = self.parse_condition()
            self.expect("]")
            expr = ArrayAccess(expr, index)
        return expr

    def parse_type(self) -> str:
        token = self.peek()
        if token.kind == "KEYWORD" and token.text in TYPE_KEYWORDS:
            self.advance()
            return token.text
        raise SyntaxError(f"Type expected at {token.line}:{token.column}")

    def is_type(self) -> bool:
        token = self.peek()
        return token.kind == "KEYWORD" and token.text in TYPE_KEYWORDS

    def check(self, text: str) -> bool:
        return self.peek().text == text

    def match(self, text: str) -> bool:
        if self.check(text):
            self.advance()
            return True
        return False

    def match_keyword(self, text: str) -> bool:
        token = self.peek()
        if token.kind == "KEYWORD" and token.text == text:
            self.advance()
            return True
        return False

    def expect(self, text: str) -> Token:
        token = self.peek()
        if token.text != text:
            raise SyntaxError(f"Expected {text!r} at {token.line}:{token.column}, got {token.text!r}")
        return self.advance()

    def expect_kind(self, kind: str) -> Token:
        token = self.peek()
        if token.kind != kind:
            raise SyntaxError(f"Expected {kind} at {token.line}:{token.column}, got {token.kind}")
        return self.advance()

    def expect_ident(self) -> str:
        token = self.expect_kind("IDENT")
        return token.text

    def peek(self) -> Token:
        return self.tokens[self.pos]

    def advance(self) -> Token:
        token = self.tokens[self.pos]
        self.pos += 1
        return token

