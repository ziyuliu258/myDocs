.section .data
.align 3
a: .skip 80

.section .text
.global swap
swap:
    STP X29, X30, [SP, #-16]!
    MOV X29, SP
    SUB SP, SP, #112
    STR X19, [SP, #0]
    STR X20, [SP, #8]
    STR X21, [SP, #16]
    STR X22, [SP, #24]
    STR X23, [SP, #32]
    STR X24, [SP, #40]
    STR X25, [SP, #48]
    STR X26, [SP, #56]
    STR X27, [SP, #64]
    STR X28, [SP, #72]
    MOV X19, X0
    MOV X20, X1
    MOV X21, X2
    LSL X11, X20, #3
    MOV X22, X11
    MOV X9, X19
    MOV X10, X22
    ADD X9, X9, X10
    LDR X25, [X9]
    LSL X11, X21, #3
    MOV X26, X11
    MOV X9, X19
    MOV X10, X26
    ADD X9, X9, X10
    LDR X28, [X9]
    LSL X11, X20, #3
    STR X11, [SP, #80]
    MOV X9, X19
    LDR X10, [SP, #80]
    ADD X11, X9, X10
    STR X11, [SP, #88]
    LDR X9, [SP, #88]
    STR X28, [X9]
    LSL X11, X21, #3
    STR X11, [SP, #96]
    MOV X9, X19
    LDR X10, [SP, #96]
    ADD X11, X9, X10
    STR X11, [SP, #104]
    LDR X9, [SP, #104]
    STR X25, [X9]
    MOV X0, #0
.L_return_swap:
    LDR X19, [SP, #0]
    LDR X20, [SP, #8]
    LDR X21, [SP, #16]
    LDR X22, [SP, #24]
    LDR X23, [SP, #32]
    LDR X24, [SP, #40]
    LDR X25, [SP, #48]
    LDR X26, [SP, #56]
    LDR X27, [SP, #64]
    LDR X28, [SP, #72]
    ADD SP, SP, #112
    LDP X29, X30, [SP], #16
    RET

.global partition
partition:
    STP X29, X30, [SP, #-16]!
    MOV X29, SP
    SUB SP, SP, #160
    STR X19, [SP, #0]
    STR X20, [SP, #8]
    STR X21, [SP, #16]
    STR X22, [SP, #24]
    STR X23, [SP, #32]
    STR X24, [SP, #40]
    STR X25, [SP, #48]
    STR X26, [SP, #56]
    STR X27, [SP, #64]
    STR X28, [SP, #72]
    MOV X19, X0
    MOV X20, X1
    MOV X21, X2
    LSL X11, X21, #3
    MOV X22, X11
    MOV X9, X19
    MOV X10, X22
    ADD X9, X9, X10
    LDR X25, [X9]
    SUB X27, X20, #1
    SUB X28, X20, #1
    STR X28, [SP, #80]
.L_partition_l0:
    LDR X9, [SP, #80]
    ADD X11, X9, #1
    STR X11, [SP, #88]
    LDR X9, [SP, #88]
    STR X9, [SP, #80]
    LDR X9, [SP, #80]
    MOV X10, X21
    CMP X9, X10
    B.LT .L_partition_l1
    B .L_partition_l2
.L_partition_l1:
    LDR X9, [SP, #80]
    LSL X11, X9, #3
    STR X11, [SP, #96]
    MOV X9, X19
    LDR X10, [SP, #96]
    ADD X11, X9, X10
    STR X11, [SP, #104]
    LDR X9, [SP, #104]
    LDR X10, [X9]
    STR X10, [SP, #112]
    LDR X9, [SP, #112]
    MOV X10, X25
    CMP X9, X10
    B.LT .L_partition_l3
    B .L_partition_l4
.L_partition_l3:
    ADD X11, X27, #1
    STR X11, [SP, #120]
    LDR X27, [SP, #120]
    MOV X0, X19
    MOV X1, X27
    LDR X2, [SP, #80]
    BL swap
    STR X0, [SP, #128]
    B .L_partition_l5
.L_partition_l4:
.L_partition_l5:
    B .L_partition_l0
.L_partition_l2:
    ADD X11, X27, #1
    STR X11, [SP, #136]
    MOV X0, X19
    LDR X1, [SP, #136]
    MOV X2, X21
    BL swap
    STR X0, [SP, #144]
    ADD X11, X27, #1
    STR X11, [SP, #152]
    LDR X0, [SP, #152]
.L_return_partition:
    LDR X19, [SP, #0]
    LDR X20, [SP, #8]
    LDR X21, [SP, #16]
    LDR X22, [SP, #24]
    LDR X23, [SP, #32]
    LDR X24, [SP, #40]
    LDR X25, [SP, #48]
    LDR X26, [SP, #56]
    LDR X27, [SP, #64]
    LDR X28, [SP, #72]
    ADD SP, SP, #160
    LDP X29, X30, [SP], #16
    RET

.global qsort
qsort:
    STP X29, X30, [SP, #-16]!
    MOV X29, SP
    SUB SP, SP, #80
    STR X19, [SP, #0]
    STR X20, [SP, #8]
    STR X21, [SP, #16]
    STR X22, [SP, #24]
    STR X23, [SP, #32]
    STR X24, [SP, #40]
    STR X25, [SP, #48]
    STR X26, [SP, #56]
    STR X27, [SP, #64]
    MOV X19, X0
    MOV X20, X1
    MOV X21, X2
    MOV X9, X20
    MOV X10, X21
    CMP X9, X10
    B.LT .L_qsort_l0
    B .L_qsort_l1
.L_qsort_l0:
    MOV X0, X19
    MOV X1, X20
    MOV X2, X21
    BL partition
    MOV X22, X0
    MOV X23, X22
    SUB X24, X23, #1
    MOV X0, X19
    MOV X1, X20
    MOV X2, X24
    BL qsort
    MOV X25, X0
    ADD X26, X23, #1
    MOV X0, X19
    MOV X1, X26
    MOV X2, X21
    BL qsort
    MOV X27, X0
    B .L_qsort_l2
.L_qsort_l1:
.L_qsort_l2:
    MOV X0, #0
.L_return_qsort:
    LDR X19, [SP, #0]
    LDR X20, [SP, #8]
    LDR X21, [SP, #16]
    LDR X22, [SP, #24]
    LDR X23, [SP, #32]
    LDR X24, [SP, #40]
    LDR X25, [SP, #48]
    LDR X26, [SP, #56]
    LDR X27, [SP, #64]
    ADD SP, SP, #80
    LDP X29, X30, [SP], #16
    RET

.global _start
_start:
    ADR X0, a
    MOV X1, #0
    MOV X2, #9
    BL qsort
    MOV X19, X0
    MOV X0, #0
    MOV X8, #93
    SVC #0
