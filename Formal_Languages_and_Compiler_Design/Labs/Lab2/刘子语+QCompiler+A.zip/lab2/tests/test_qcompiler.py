import unittest

from qcompiler.compiler import compile_source
from qcompiler.lexer import Lexer


QSORT_SOURCE = """
{
int a[10];

void swap(int arr[]; int i; int j;) {
    int temp;
    temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}

int partition(int arr[]; int low; int high;) {
    // pivot is the last element
    int pivot;
    int i;
    int j;
    pivot = arr[high];
    i = low - 1;
    j = low - 1;
    while ((j = j + 1) < high) {
        if (arr[j] < pivot) {
            i = i + 1;
            swap(arr[], i, j,);
        }
    }
    swap(arr[], i + 1, high,);
    return i + 1;
}

void qsort(int arr[]; int low; int high;) {
    int p;
    if (low < high) {
        p = partition(arr, low, high,);
        qsort(arr, low, p - 1,);
        qsort(arr, p + 1, high,);
    }
}

qsort(a[], 0, 9,);
}
"""


class QCompilerPipelineTests(unittest.TestCase):
    def test_lexer_strips_comments_and_normalizes_en_dash(self):
        tokens = Lexer().tokenize("{ // comment\n int x; x = 3 – 1; }")
        texts = [token.text for token in tokens]
        self.assertNotIn("//", texts)
        self.assertIn("-", texts)
        self.assertEqual(texts.count("int"), 1)

    def test_array_assignment_generates_qtac_memory_store(self):
        result = compile_source(
            """
            {
            int a[2];
            void set(int v;) {
                int i;
                i = 0;
                a[i] = v;
            }
            set(7,);
            }
            """
        )
        self.assertIn("M[", result.qtac)
        self.assertIn("define set(v){", result.qtac)
        self.assertIn("t", result.qtac)
        self.assertIn("a: .skip 16", result.arm)

    def test_compiles_qsort_through_tokens_ast_qtac_and_arm(self):
        result = compile_source(QSORT_SOURCE)

        self.assertGreater(len(result.tokens), 100)
        self.assertIn("qsort", result.ast_json)
        self.assertIn('"node": "FunctionDecl"', result.ast_json)
        self.assertIn('"node": "Call"', result.ast_json)
        self.assertIn("define partition(arr, low, high){", result.qtac)
        self.assertIn("CALL qsort, 3", result.qtac)
        self.assertIn(".global _start", result.arm)
        self.assertIn("BL qsort", result.arm)
        self.assertIn("a: .skip 80", result.arm)
        self.assertLessEqual(len(result.optimized_arm.splitlines()), len(result.arm.splitlines()))

    def test_arm_emits_each_function_entry_label_once(self):
        result = compile_source(QSORT_SOURCE)
        self.assertEqual(result.arm.splitlines().count("swap:"), 1)
        self.assertEqual(result.arm.splitlines().count("partition:"), 1)
        self.assertEqual(result.arm.splitlines().count("qsort:"), 1)

    def test_arm_uses_function_scoped_control_labels(self):
        result = compile_source(QSORT_SOURCE)
        self.assertNotIn("\nl0:", result.arm)
        self.assertIn(".L_partition_l0:", result.arm)
        self.assertIn("B.LT .L_qsort_l0", result.arm)

    def test_optimizer_uses_strength_reduction_and_reduces_more_than_trivial_branches(self):
        result = compile_source(QSORT_SOURCE)
        unoptimized_lines = result.arm.splitlines()
        optimized_lines = result.optimized_arm.splitlines()

        self.assertIn("LSL", result.optimized_arm)
        self.assertLessEqual(len(optimized_lines), len(unoptimized_lines) - 20)
        self.assertNotIn("MOV X10, #8\n    MUL", result.optimized_arm)

    def test_optimizer_keeps_function_parameter_register_initialization(self):
        result = compile_source(QSORT_SOURCE)
        self.assertGreaterEqual(result.optimized_arm.count("MOV X19, X0"), 3)
        self.assertGreaterEqual(result.optimized_arm.count("MOV X20, X1"), 3)
        self.assertGreaterEqual(result.optimized_arm.count("MOV X21, X2"), 3)


if __name__ == "__main__":
    unittest.main()
